#include <Adafruit_HTU21DF.h>

// Replace with keys obtained from TheThingsNetwork console
#define SECRET_APP_EUI "70B3D57ED002D841";
#define SECRET_APP_KEY "BED5EA9CFE74384F5912D8E17B0AF900";  
